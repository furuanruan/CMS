<?php

return array(
	'admin_scripts',
	'ajax_delete_link',
	'ajax_install_link_posts',
	'ajax_install_save_words',
	'delete_words',
	'frontend_css',
	'link_related_screen',
	'meta_box',
	'meta_box_ajax_sort',
	'page_install',
	'post_type',
	'related_auto_link',
	'related_update_link',
	'related_save_words',
	'settings_page',
	'shortcode',
	'widget'
);