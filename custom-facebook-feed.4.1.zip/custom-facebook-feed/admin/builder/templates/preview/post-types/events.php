<section id="cff-post-list-section" class="cff-preview-posts-list-ctn cff-fb-fs cff-preview-section" :data-dimmed="!isSectionHighLighted('postList')" v-if="customizerFeedData.settings.feedtype == 'events'">

</section>