<script type="text/x-template" id="cff-post-reviewspost-component">
	<cff-post-author-component :single-post="singlePost" :customizer-feed-data="customizerFeedData"></cff-post-author-component>
</script>
<cff-post-reviewspost-component :customizer-feed-data="customizerFeedData"></cff-post-reviewspost-component>