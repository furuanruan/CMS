<?php
if ( ! defined( 'ABSPATH' ) ) exit;

include ULPB_PLUGIN_PATH.'/integrations/form-builder-database/extension.php';

include 'admin/classes/admin.php';
include 'admin/classes/ajax-requests-class.php';

include 'init/init.php';

include 'admin/views/ask-review.php';

?>