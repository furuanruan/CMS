<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<p> Discontinued, Please email support@pluginops.com for more information. </p>

<style>
          .email_subs_tab_ppb {
            display:none !important;
          }
</style>